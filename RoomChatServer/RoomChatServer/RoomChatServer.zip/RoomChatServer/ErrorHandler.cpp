#include "ErrorHandler.h"



CErrorHandler::CErrorHandler()
{
}


CErrorHandler::~CErrorHandler()
{
}
